//Ubah disini bro
//SUBSCRIBE YT : Delta Tech
global.baileys1 = require('@whiskeysockets/baileys') 
global.prefa = ['','!','.',',','⚡','🤡']
global.nocreator = ['6283840133231']
global.owner = ['6283840133231']
global.botname = 'BOT BUG PRIVAT RAKA
global.sticker1 = "RAKA"
global.sticker2 = "RAKA"